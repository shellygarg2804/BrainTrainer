package com.example.braintrainer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button startButton;

    ArrayList<Integer> answers= new ArrayList<Integer>();
    int locationofcorrectanswer;
    //Button button0= (Button)findViewById(R.id.button0);
    Button button1= (Button)findViewById(R.id.button1);
    Button button2= (Button)findViewById(R.id.button2);
    Button button3= (Button)findViewById(R.id.button3);



    public void start(View view){

        startButton.setVisibility(View.INVISIBLE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton =(Button) findViewById(R.id.GoButton);
        TextView sumtextview= (TextView)findViewById(R.id.sumTextView) ;
        Random random= new Random();
        int a= random.nextInt(21);
        int b= random.nextInt(21);
        sumtextview.setText(Integer.toString(a)+" + "+Integer.toString(b));

        locationofcorrectanswer=random.nextInt(4);

        int incorrectanswer;

        for(int i=0;i<4;i++){
            if(i==locationofcorrectanswer){
                answers.add(a+b);
            }
            else{

                incorrectanswer=random.nextInt(41);
                while(incorrectanswer==a+b){

                    incorrectanswer=random.nextInt(41);

                }
                answers.add(incorrectanswer);
            }
        }

        //button0.setText(Integer.toString(answers.get(0)));
        button1.setText(Integer.toString(answers.get(1)));
        button2.setText(Integer.toString(answers.get(2)));
        button3.setText(Integer.toString(answers.get(3)));

    }
}
